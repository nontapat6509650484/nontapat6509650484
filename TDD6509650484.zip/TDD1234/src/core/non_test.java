package core;

public class non_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Test");
	}

}
